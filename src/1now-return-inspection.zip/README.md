# 1Now Fleet Ops: Return Inspection

Next.js 14 (App Router) + Tailwind CSS 3 + lucide-react. The whole feature lives in `app/page.tsx`.

    npm install
    npm run dev      # http://localhost:3000
    npm run build && npm start   # production

Fonts (Inter Tight, JetBrains Mono) are self-hosted via @fontsource, so no Google Fonts request is needed.
